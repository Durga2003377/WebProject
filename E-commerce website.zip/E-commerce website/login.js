app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const sql = "SELECT * FROM users WHERE email = ?";
    db.query(sql, [email], async (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            const isMatch = await bcrypt.compare(password, results[0].password_hash);
            if (isMatch) {
                res.send("Login successful!");
            } else {
                res.send("Incorrect password!");
            }
        } else {
            res.send("User not found!");
        }
    });
});
