const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");
const bcrypt = require("bcrypt");
require("dotenv").config();

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

// Database connection
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
});

db.connect((err) => {
    if (err) throw err;
    console.log("Database connected!");
});

// Signup route
app.post("/signup", async (req, res) => {
    const { fullName, mobileNumber, email, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = "INSERT INTO users (full_name, mobile_number, email, password_hash) VALUES (?, ?, ?, ?)";
    db.query(sql, [fullName, mobileNumber, email, hashedPassword], (err) => {
        if (err) {
            if (err.code === "ER_DUP_ENTRY") {
                return res.status(400).send("Email already exists!");
            }
            return res.status(500).send("Error occurred!");
        }
        res.send("Signup successful!");
    });
});

// Login route
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const sql = "SELECT * FROM users WHERE email = ?";
    db.query(sql, [email], async (err, results) => {
        if (err) return res.status(500).send("Error occurred!");

        if (results.length > 0) {
            const isMatch = await bcrypt.compare(password, results[0].password_hash);
            if (isMatch) {
                return res.send("Login successful!");
            }
            return res.status(400).send("Incorrect password!");
        }
        res.status(404).send("User not found!");
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
