const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const mysql = require("mysql");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "eshopy",
});

db.connect((err) => {
    if (err) throw err;
    console.log("Connected to the database!");
});

app.post("/signup", async (req, res) => {
    const { fullName, mobileNumber, email, password } = req.body;

    // Hash the password for security
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = "INSERT INTO users (full_name, mobile_number, email, password_hash) VALUES (?, ?, ?, ?)";
    db.query(sql, [fullName, mobileNumber, email, hashedPassword], (err) => {
        if (err) {
            if (err.code === "ER_DUP_ENTRY") {
                res.send("Email already exists!");
            } else {
                console.error(err);
                res.send("Error occurred!");
            }
        } else {
            res.send("Signup successful!");
        }
    });
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
